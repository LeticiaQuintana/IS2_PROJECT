package com.example.scrumis2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class VerUsuariosActivity extends AppCompatActivity {

    private ListView list1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_usuarios);

        list1 = (ListView) findViewById(R.id.list_users);

        String json = ConexionManager.executePost("http://192.168.0.16:8080/ScrumRestFull/webresources/org.postgres.entities.usuarios");
        jsonConvert(json);
    }


    private void jsonConvert(String msgJson){
        try{
            List<String> contes = new ArrayList<String>();
            JSONObject obj = new JSONObject(msgJson);
            System.out.println("obj "+obj);
            JSONArray lista = obj.optJSONArray("contenidos");
            for(int i = 0; i < lista.length(); i++){
                JSONObject json_data = lista.getJSONObject(i);
                String conte = json_data.getString("nombre") + " " + json_data.getString("apellido")+ " " +
                        json_data.getString("email") + " " + json_data.getString("telefono");
                contes.add(conte);
                System.out.println("conte :"+ contes);
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.activity_list_item, contes);
            list1.setAdapter(adapter);
        } catch (JSONException e) {
            Toast.makeText(this, "Error al cargar la lista:" + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }finally {

        }
    }
}

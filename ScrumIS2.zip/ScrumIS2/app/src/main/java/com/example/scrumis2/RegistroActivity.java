package com.example.scrumis2;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class RegistroActivity extends AppCompatActivity {

    private Button btn_resgistrar;
    private EditText name, lastName, email, telephone, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        btn_resgistrar = (Button) findViewById(R.id.btn_registrar_user);
        name = (EditText) findViewById(R.id.textName);
        lastName = (EditText) findViewById(R.id.textLastName);
        email = (EditText) findViewById(R.id.textEmail);

        btn_resgistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(RegistroActivity.this, "Iniciando Registro", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private class InvocarServicioRegistrarUsuarios extends AsyncTask<Void, Integer, Void> {
        private int progreso;

        @Override
        protected Void doInBackground(Void... voids) {
            registrarServicio();
            return null;
        }

        @Override
        protected void onPostExecute(Void result){
            btn_resgistrar.setClickable(true);
            Toast.makeText(RegistroActivity.this, "Usuario Registrado", Toast.LENGTH_SHORT).show();
        }

        @Override
        protected  void onProgressUpdate(Integer... values){

        }
    }

    private void registrarServicio(){

        HashMap<String, String> parameters = new HashMap<String, String>();
        parameters.put("nombre", name.getText().toString());
        parameters.put("apellido", lastName.getText().toString());
        parameters.put("email", email.getText().toString());
        parameters.put("telefono", telephone.getText().toString());

        String response = "";
        try{
            URL url = new URL("http://192.168.0.16:8080/ScrumRestFull/webresources/org.postgres.entities.usuarios");

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(15000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("POST");
            conn.setDoInput(true);
            conn.setDoOutput(true);

            OutputStream os = conn.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
            writer.write(getPostDataString(parameters));

            writer.flush();
            writer.close();
            os.close();
            int responseCode = conn.getResponseCode();

            if(responseCode == HttpURLConnection.HTTP_OK){
                String line;
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                while((line = br.readLine()) != null){
                    response += line;
                }
            }else{
                response = "";
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for(Map.Entry<String, String> entry : params.entrySet()){
            if(first) first = false;
            else result.append("&");
            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));

        }
        return result.toString();
    }
}

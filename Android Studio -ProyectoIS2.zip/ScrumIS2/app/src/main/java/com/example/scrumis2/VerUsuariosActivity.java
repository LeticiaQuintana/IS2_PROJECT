package com.example.scrumis2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class VerUsuariosActivity extends AppCompatActivity {

    private ListView list1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_usuarios);

        list1 = (ListView) findViewById(R.id.list_users);

        String result = ConexionManager.executePost("http://192.168.0.16:8080/ScrumRestFull/webresources/org.postgres.entities.usuarios");

        try {
            JSONArray jArray = new JSONArray(result);
            JSONObject jo = new JSONObject();
            jo.put("arrayName",jArray);
            System.out.println("aaa"+jArray);
            jsonConvertir(jo);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private void jsonConvertir(JSONObject obj){
        try{
            System.out.println("Entra a la funcion");
            List<String> contes = new ArrayList<String>();
            //JSONObject obj = new JSONObject(msgJson);
            System.out.println("obj "+obj);
            JSONArray lista = obj.optJSONArray("arrayName");
            System.out.println("JSONArray lista: "+lista);
            for(int i = 0; i < lista.length(); i++){
                JSONObject json_data = lista.getJSONObject(i);
                System.out.println("JSONObject json_data: "+json_data);
                String conte = json_data.getString("nombre") + " " + json_data.getString("apellido")+ " " +
                        json_data.getString("email") + " " + json_data.getString("telefono");
                contes.add(conte);
                System.out.println("conte :"+ contes);
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, contes);
            list1.setAdapter(adapter);
        } catch (JSONException e) {
            Toast.makeText(this, "Error al cargar la lista:" + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }finally {

        }
    }
}

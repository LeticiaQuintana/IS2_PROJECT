package com.example.scrumis2;

import android.annotation.SuppressLint;
import android.os.StrictMode;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ConexionManager {

    @SuppressLint("WrongConstant")
    public static String executePost(String targetURL) {
        int timeout=5000;
        String result;
        String inputLine;
        URL url;
        HttpURLConnection connection = null;
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        //Se intenta hacer la conexion
        try {
            url = new URL(targetURL);
            connection = (HttpURLConnection) url.openConnection();

            System.out.println("   CONEXIÓN!!"+connection);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json");
               /*

                connection.setUseCaches(false);
                connection.setDoInput(true);
                connection.setDoOutput(true);
                connection.setConnectTimeout(timeout);
                connection.setReadTimeout(timeout);*/

            int status = connection.getResponseCode();
            System.out.println("estado!! "+status);
            connection.connect();

            //Create a new InputStreamReader
            InputStreamReader streamReader = new
                    InputStreamReader(connection.getInputStream());
            //Create a new buffered reader and String Builder
            BufferedReader reader = new BufferedReader(streamReader);
            StringBuilder stringBuilder = new StringBuilder();
            //Check if the line we are reading is not null
            while((inputLine = reader.readLine()) != null){
                stringBuilder.append(inputLine);
            }
            //Close our InputStream and Buffered reader
            reader.close();
            streamReader.close();
            //Set our result equal to our stringBuilder
            result = stringBuilder.toString();
            System.out.println("resultttt "+result);

            // Se envia la peticion
                /*DataOutputStream wr = new DataOutputStream(connection.getOutputStream());

               // wr.writeBytes(urlParameters);
                wr.flush();
                wr.close();

                // Obtiene resultados de la peticion realizada
                InputStream is = connection.getInputStream();
                System.out.println("issss "+is);
                BufferedReader rd = new BufferedReader(new InputStreamReader(is));
                String line;
                StringBuffer response = new StringBuffer();
                while ((line = rd.readLine()) != null) {
                    response.append(line);
                    response.append('\r');
                }

                rd.close();*/
            return result;

        } catch (Exception e) {
            //Toast.makeText(R.layout.activity_main, "Error de conexión", 10).show();
            e.printStackTrace();
        } finally {

            if (connection != null) {
                connection.disconnect();
            }
        }
        return null;
    }





}

package com.example.scrumis2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Main3Activity extends AppCompatActivity {
    private ListView list;
    private String[] opciones = {"Listar", "Registrar", "Editar", "Eliminar"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        list = (ListView) findViewById(R.id.menu_us);
        ArrayAdapter adapter = new ArrayAdapter(this, R.layout.activity_main3, opciones);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                String opcion = list.getItemAtPosition(position).toString();
                if(opcion.equals("Listar")){
                  /*  Intent intent = new Intent(Main3Activity.this, pagina.class);
                    startActivity(intent);*/
                }else if(opcion.equals("Registrar")) {

                }
            }
        });
    }
}

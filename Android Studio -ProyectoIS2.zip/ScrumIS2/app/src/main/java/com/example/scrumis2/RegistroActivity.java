package com.example.scrumis2;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class RegistroActivity extends AppCompatActivity {

    private Button btn_resgistrar;
    private EditText name, lastName, email, telephone, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        btn_resgistrar = (Button) findViewById(R.id.btn_registrar_user);
        name = (EditText) findViewById(R.id.textName);
        lastName = (EditText) findViewById(R.id.textLastName);
        email = (EditText) findViewById(R.id.textEmail);
        telephone = (EditText) findViewById(R.id.textCelular);
        password = (EditText) findViewById(R.id.textPass);


      /*  name.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        lastName.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        email.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        telephone.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        password.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);*/

   /*    btn_resgistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(RegistroActivity.this, "Iniciando Registro", Toast.LENGTH_SHORT).show();

                InvocarServicioRegistrarUsuarios servicio = new InvocarServicioRegistrarUsuarios();
                servicio.execute();
            }
        });*/

        btn_resgistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    System.out.println(registrarServicio());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });


    }


 /*  private class InvocarServicioRegistrarUsuarios extends AsyncTask<Void, Integer, Void> {
        private int progreso;

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                registrarServicio();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result){
            btn_resgistrar.setClickable(true);
            Toast.makeText(RegistroActivity.this, "Usuario Registrado", Toast.LENGTH_SHORT).show();
        }

        @Override
        protected  void onProgressUpdate(Integer... values){

        }
    }*/

    @SuppressLint("WrongConstant")
    private int registrarServicio() throws JSONException {

       // HashMap<String, String> parameters = new HashMap<String, String>();
        JSONObject parameters = new JSONObject();
        parameters.put("nombre", name.getText().toString());
        parameters.put("apellido", lastName.getText().toString());
        parameters.put("email", email.getText().toString());
        parameters.put("telefono", telephone.getText().toString());
        parameters.put("estado", 1);
        parameters.put("detalleEstado", "ninguno");
        parameters.put("root", 0);
        parameters.put("id", 9);
        String response = "";

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        URL url;
        HttpURLConnection connection = null;
        try {

            //se establece una conexion con el servidor
            url = new URL("http://192.168.0.16:8080/ScrumRestFull/webresources/org.postgres.entities.usuarios");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");

            connection.setUseCaches(false);
            connection.setDoInput(true);
            connection.setDoOutput(true);
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);


         /*   int status = connection.getResponseCode();
            System.out.println("Estado de la conexion al registrar!! "+status);*/
            //envia la peticion al servidor
            DataOutputStream wr = new DataOutputStream(
                    connection.getOutputStream());
            wr.writeBytes(String.valueOf(parameters));
            wr.flush();
            wr.close();

            return connection.getResponseCode();

        } catch (Exception e) {
            Toast.makeText(this,"Error de conexión",7000).show();
            e.printStackTrace();
        } finally {

            if (connection != null) {
                connection.disconnect();
            }
        }
        return 0;

     /*   URL url;
        HttpURLConnection conn = null;
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        try{


            url = new URL("http://192.168.0.16:8080/ScrumRestFull/webresources/org.postgres.entities.usuarios");

            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");

            int status = conn.getResponseCode();
            System.out.println("Estado de la conexion al registrar!! "+status);
            OutputStream os = conn.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
            writer.write(getPostDataString(parameters));

            writer.flush();
            writer.close();
            os.close();
            int responseCode = conn.getResponseCode();

            if(responseCode == HttpURLConnection.HTTP_OK){
                String line;
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                while((line = br.readLine()) != null){
                    response += line;
                }
            }else{
                response = "";
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }

    private String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for(Map.Entry<String, String> entry : params.entrySet()){
            if(first) first = false;
            else result.append("&");
            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));

        }
        System.out.println("Result !! "+result.toString());
        return result.toString();
    }
}
